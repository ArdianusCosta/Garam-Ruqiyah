globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/csTrQ6mXkhaWkDvhE545b/_buildManifest.js",
    "static/csTrQ6mXkhaWkDvhE545b/_ssgManifest.js",
    "static/csTrQ6mXkhaWkDvhE545b/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3mc6dra1m0098.js",
    "static/chunks/0fy4h0ngk1igg.js",
    "static/chunks/3byuobrkyz9bj.js",
    "static/chunks/3hqxib_yoa_0b.js",
    "static/chunks/11jq0c2_zavac.js",
    "static/chunks/turbopack-0hlt_6mog4okm.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
