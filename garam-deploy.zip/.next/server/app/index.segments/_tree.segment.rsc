:HL["/_next/static/chunks/39oub11gxraxv.css","style"]
:HL["/_next/static/chunks/22atpt_f_65u8.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}},"staleTime":300,"buildId":"csTrQ6mXkhaWkDvhE545b"}
