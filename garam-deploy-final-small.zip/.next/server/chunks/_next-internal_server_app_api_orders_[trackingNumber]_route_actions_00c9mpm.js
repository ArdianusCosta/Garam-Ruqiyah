module.exports=[81173,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_orders_%5BtrackingNumber%5D_route_actions_00c9mpm.js.map