module.exports=[1815,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_webhook_ipaymu_route_actions_04sharx.js.map