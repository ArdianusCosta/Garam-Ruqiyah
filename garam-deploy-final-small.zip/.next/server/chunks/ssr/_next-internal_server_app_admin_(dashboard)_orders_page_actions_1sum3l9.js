module.exports=[77844,a=>{"use strict";var b=a.i(9223);a.s([],12829),a.i(12829),a.s(["0082e5ed293df32dfaa2afc7d6811bfdf78d173389",()=>b.logoutAction],77844)}];

//# sourceMappingURL=_next-internal_server_app_admin_%28dashboard%29_orders_page_actions_1sum3l9.js.map