module.exports=[38022,a=>{"use strict";var b=a.i(9223);a.s([],98375),a.i(98375),a.s(["0082e5ed293df32dfaa2afc7d6811bfdf78d173389",()=>b.logoutAction],38022)}];

//# sourceMappingURL=_next-internal_server_app_admin_%28dashboard%29_payments_page_actions_1oqvz06.js.map