module.exports=[17709,a=>{"use strict";var b=a.i(9223);a.s([],54308),a.i(54308),a.s(["0082e5ed293df32dfaa2afc7d6811bfdf78d173389",()=>b.logoutAction],17709)}];

//# sourceMappingURL=_next-internal_server_app_admin_%28dashboard%29_profile_page_actions_09oxad7.js.map