module.exports=[6733,a=>{"use strict";var b=a.i(9223);a.s([],6731),a.i(6731),a.s(["0082e5ed293df32dfaa2afc7d6811bfdf78d173389",()=>b.logoutAction],6733)}];

//# sourceMappingURL=_next-internal_server_app_admin_%28dashboard%29_tracking_page_actions_0w4qy0o.js.map