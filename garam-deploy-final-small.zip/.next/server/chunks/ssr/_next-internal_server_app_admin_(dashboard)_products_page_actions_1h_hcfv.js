module.exports=[8287,a=>{"use strict";var b=a.i(9223);a.s([],46036),a.i(46036),a.s(["0082e5ed293df32dfaa2afc7d6811bfdf78d173389",()=>b.logoutAction],8287)}];

//# sourceMappingURL=_next-internal_server_app_admin_%28dashboard%29_products_page_actions_1h_hcfv.js.map