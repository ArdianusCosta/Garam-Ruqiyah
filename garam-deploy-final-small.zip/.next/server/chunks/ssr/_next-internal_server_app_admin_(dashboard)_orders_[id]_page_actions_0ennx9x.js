module.exports=[38378,a=>{"use strict";var b=a.i(9223);a.s([],10142),a.i(10142),a.s(["0082e5ed293df32dfaa2afc7d6811bfdf78d173389",()=>b.logoutAction],38378)}];

//# sourceMappingURL=_next-internal_server_app_admin_%28dashboard%29_orders_%5Bid%5D_page_actions_0ennx9x.js.map