module.exports=[43780,a=>{"use strict";var b=a.i(9223);a.s([],6034),a.i(6034),a.s(["0082e5ed293df32dfaa2afc7d6811bfdf78d173389",()=>b.logoutAction],43780)}];

//# sourceMappingURL=_next-internal_server_app_admin_%28dashboard%29_cms_page_actions_0-swkvn.js.map