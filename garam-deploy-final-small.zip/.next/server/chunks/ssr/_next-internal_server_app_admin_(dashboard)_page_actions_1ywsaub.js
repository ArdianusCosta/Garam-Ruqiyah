module.exports=[50793,a=>{"use strict";var b=a.i(9223);a.s([],5528),a.i(5528),a.s(["0082e5ed293df32dfaa2afc7d6811bfdf78d173389",()=>b.logoutAction],50793)}];

//# sourceMappingURL=_next-internal_server_app_admin_%28dashboard%29_page_actions_1ywsaub.js.map