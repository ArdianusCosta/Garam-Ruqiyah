var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/webhook/ipaymu/route.js")
R.c("server/chunks/[root-of-the-server]__07viwfd._.js")
R.c("server/chunks/[root-of-the-server]__01jo1hx._.js")
R.c("server/chunks/_next-internal_server_app_api_webhook_ipaymu_route_actions_04sharx.js")
R.m(48309)
module.exports=R.m(48309).exports
