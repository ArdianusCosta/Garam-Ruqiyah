var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/orders/[trackingNumber]/route.js")
R.c("server/chunks/[root-of-the-server]__0gu6mlk._.js")
R.c("server/chunks/[root-of-the-server]__01jo1hx._.js")
R.c("server/chunks/_next-internal_server_app_api_orders_[trackingNumber]_route_actions_00c9mpm.js")
R.m(73364)
module.exports=R.m(73364).exports
