var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/orders/route.js")
R.c("server/chunks/[externals]__0c2rtfl._.js")
R.c("server/chunks/[root-of-the-server]__01jo1hx._.js")
R.c("server/chunks/[root-of-the-server]__0wx87sp._.js")
R.c("server/chunks/_next-internal_server_app_api_orders_route_actions_18oip2y.js")
R.m(81585)
module.exports=R.m(81585).exports
