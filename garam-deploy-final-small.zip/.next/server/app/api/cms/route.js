var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/cms/route.js")
R.c("server/chunks/[root-of-the-server]__1z4gk8e._.js")
R.c("server/chunks/[root-of-the-server]__01jo1hx._.js")
R.c("server/chunks/_next-internal_server_app_api_cms_route_actions_1nrx8mj.js")
R.m(67044)
module.exports=R.m(67044).exports
